import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ivan_notes/main.dart';

void main() {
  testWidgets('Заметка сохраняется, редактируется и удаляется',
      (tester) async {
    await tester.pumpWidget(const IvanNotesApp());

    await tester.enterText(find.byType(TextField), 'Сдать курсовую');
    await tester.tap(find.text('Сохранить'));
    await tester.pump();
    expect(find.text('Сдать курсовую'), findsOneWidget);

    await tester.tap(find.byIcon(Icons.edit_outlined));
    await tester.pump();
    await tester.enterText(find.byType(TextField), 'Сдать курсовую на 5');
    await tester.tap(find.text('Обновить'));
    await tester.pump();
    expect(find.text('Сдать курсовую на 5'), findsOneWidget);

    await tester.tap(find.byIcon(Icons.close_rounded));
    await tester.pump();
    expect(find.text('Сдать курсовую на 5'), findsNothing);
  });
}

import 'package:flutter/material.dart';

// «Блокнот Ивана» — личное приложение-заметки
// Автор: Спиридонов Иван Дмитриевич
void main() => runApp(const IvanNotesApp());

const String authorFull = 'Спиридонов Иван Дмитриевич';
const String authorShort = 'Спиридонов И. Д.';

class IvanNotesApp extends StatelessWidget {
  const IvanNotesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Блокнот Ивана',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF3D4A8C),
        scaffoldBackgroundColor: const Color(0xFFF3F0FA),
      ),
      home: const NotesScreen(),
    );
  }
}

// Модель заметки
class Note {
  static int _counter = 0;

  Note(this.text)
      : created = DateTime.now(),
        colorIndex = _counter++ % stickerColors.length;

  String text;
  final DateTime created;
  final int colorIndex;
}

// Цвета стикеров
const List<Color> stickerColors = [
  Color(0xFFFFE3A8), // янтарный
  Color(0xFFD9D2F6), // лавандовый
  Color(0xFFC8ECE4), // бирюзовый
  Color(0xFFFFD1DC), // розовый
];

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  final TextEditingController _input = TextEditingController();
  final List<Note> _notes = [];
  Note? _editing; // заметка, которую сейчас редактируем

  // Сохранить новую заметку или обновить существующую
  void _save() {
    final text = _input.text.trim();
    if (text.isEmpty) {
      _toast('Сначала напишите мысль ✍️');
      return;
    }
    setState(() {
      if (_editing != null) {
        _editing!.text = text;
        _editing = null;
      } else {
        _notes.insert(0, Note(text));
      }
      _input.clear();
    });
    FocusScope.of(context).unfocus();
  }

  // Начать редактирование: текст заметки переносится в поле ввода
  void _startEdit(Note note) {
    setState(() {
      _editing = note;
      _input.text = note.text;
    });
  }

  void _cancelEdit() {
    setState(() {
      _editing = null;
      _input.clear();
    });
  }

  // Удаление с возможностью вернуть заметку
  void _delete(Note note) {
    final index = _notes.indexOf(note);
    setState(() {
      _notes.remove(note);
      if (_editing == note) {
        _editing = null;
        _input.clear();
      }
    });
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Заметка выброшена в корзину'),
        action: SnackBarAction(
          label: 'Вернуть',
          onPressed: () => setState(() => _notes.insert(index, note)),
        ),
      ),
    );
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // Приветствие зависит от времени суток
  String _greeting() {
    final h = DateTime.now().hour;
    if (h >= 5 && h < 12) return 'Доброе утро';
    if (h >= 12 && h < 18) return 'Добрый день';
    if (h >= 18 && h < 23) return 'Добрый вечер';
    return 'Доброй ночи';
  }

  // Окно «Об авторе»
  void _showAbout() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('📓', style: TextStyle(fontSize: 42)),
            const SizedBox(height: 8),
            const Text(
              'Блокнот Ивана',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            const Text('Разработчик: $authorFull', textAlign: TextAlign.center),
            const SizedBox(height: 12),
            Text(
              'Сохранено заметок: ${_notes.length}\n'
              'Свайп влево или ✕ — удалить, ✎ — редактировать',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }

  String _time(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = _editing != null;

    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Заголовок с личным приветствием
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 12, 4),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 24,
                    backgroundColor: Color(0xFF3D4A8C),
                    child: Text(
                      'ИС',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${_greeting()}, Иван!',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF23284A),
                          ),
                        ),
                        Text(
                          'Блокнот Ивана · заметок: ${_notes.length}',
                          style: const TextStyle(color: Colors.black54),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Об авторе',
                    icon: const Icon(Icons.info_outline_rounded),
                    onPressed: _showAbout,
                  ),
                ],
              ),
            ),

            // Поле ввода
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: isEditing
                      ? const Color(0xFF6C5CE7)
                      : const Color(0xFFE2DACB),
                  width: 2,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  TextField(
                    controller: _input,
                    minLines: 1,
                    maxLines: 4,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: isEditing
                          ? 'Исправьте текст заметки…'
                          : 'Иван, о чём думаешь?',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (isEditing)
                        TextButton(
                          onPressed: _cancelEdit,
                          child: const Text('Отмена'),
                        ),
                      const SizedBox(width: 8),
                      FilledButton.icon(
                        onPressed: _save,
                        icon: Icon(isEditing
                            ? Icons.check_rounded
                            : Icons.push_pin_outlined),
                        label: Text(isEditing ? 'Обновить' : 'Сохранить'),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Список заметок
            Expanded(
              child: _notes.isEmpty
                  ? const Center(
                      child: Text(
                        'Иван, здесь пока пусто.\nЗапишите первую мысль 📌',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16, color: Colors.black45),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                      itemCount: _notes.length,
                      itemBuilder: (context, i) => _buildSticker(_notes[i], i),
                    ),
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Center(
                child: Text(
                  '© $authorShort',
                  style: TextStyle(fontSize: 12, color: Colors.black38),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Карточка-стикер (свайп влево — удалить)
  Widget _buildSticker(Note note, int i) {
    final highlighted = _editing == note;

    return Dismissible(
      key: ObjectKey(note),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => _delete(note),
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 24),
        margin: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: const Color(0xFFE5645A),
          borderRadius: BorderRadius.circular(14),
        ),
        child: const Icon(Icons.delete_outline, color: Colors.white),
      ),
      child: Transform.rotate(
        angle: i.isEven ? -0.012 : 0.012, // лёгкий наклон, как у бумаги
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.fromLTRB(16, 12, 6, 12),
          decoration: BoxDecoration(
            color: stickerColors[note.colorIndex],
            borderRadius: BorderRadius.circular(14),
            border: highlighted
                ? Border.all(color: const Color(0xFF6C5CE7), width: 2)
                : null,
            boxShadow: const [
              BoxShadow(
                color: Color(0x22000000),
                blurRadius: 6,
                offset: Offset(2, 3),
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '№${_notes.length - i} · ${_time(note.created)}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black45,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(note.text, style: const TextStyle(fontSize: 16)),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Редактировать',
                icon: const Icon(Icons.edit_outlined, size: 20),
                onPressed: () => _startEdit(note),
              ),
              IconButton(
                tooltip: 'Удалить',
                icon: const Icon(Icons.close_rounded, size: 20),
                onPressed: () => _delete(note),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

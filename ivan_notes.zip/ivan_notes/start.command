#!/bin/bash
# Первый запуск «Блокнота Ивана» на симуляторе iPhone
cd "$(dirname "$0")"
echo "▶ Создаю iOS-часть проекта (выполняется один раз)..."
flutter create --org com.spiridonov --project-name ivan_notes --platforms=ios .
echo "▶ Загружаю зависимости..."
flutter pub get
echo "▶ Открываю симулятор..."
open -a Simulator
sleep 8
echo "▶ Запускаю приложение..."
flutter run
